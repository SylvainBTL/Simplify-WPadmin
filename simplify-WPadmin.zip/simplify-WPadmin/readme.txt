=== Simplify WPadmin ===
Contributors: Sylvain Boutoille
Donate Link: comping soon
Tags: wordpress admin theme, admin theme, white label, admin page, wordpress admin panel, admin, plugin, admin panel, wordpress, wordpress admin panel, flat admin theme, modern admin theme, simple admin theme, admin theme style plugin, free admin theme style plugin, backend theme, custom admin theme, new admin ui, wp admin theme, wp admin page, sylvain boutoille.
Requires at least: 4.8
Tested up to: 4.8
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Clean and soft wordpress admin interface.

Feed back welcome, leaving a review on github,wordpress or slack. Thank you!

== Installation ==

1. Unzip `simplify-WPadmin.zip`
2. Upload the `simplify-WPadmin' folder to the `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

comping soon

== Changelog ==

= 1.0 =
* Initial release.
