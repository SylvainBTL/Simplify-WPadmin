<?php

/*
Plugin Name: Simplify wpadmin
Plugin URI: https://github.com/SylvainBTL/Simplify-wpadmin
Description: Clean and soft wordpress admin interface.
Author: Sylvain Boutoille
Version: 1.0.0
Author URI: sylvainboutoille.fr
*/

defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

function simplify_files() {
  wp_enqueue_style( 'simplify-wpadmin', plugins_url('css/simplify.css', __FILE__), array(), '1.0.0' );
}
	add_action( 'admin_enqueue_scripts', 'simplify_files' );
	add_action( 'login_enqueue_scripts', 'simplify_files' );


